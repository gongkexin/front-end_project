# JsLibs
要来就来一包！一包五颜六色的seajs插件,满足前端开发的各种需求。有校验插件，分页插件，ajax插件，弹窗插件等等。。
# 演示地址
  http://awei.oss-cn-shenzhen.aliyuncs.com/libs.html
# 文档
  https://github.com/awei-yu/JsLibs/wiki
# 交流反馈
  https://github.com/awei-yu/JsLibs/issues <br>
  QQ群:515660304
# 推荐使用sealoader管理您的seajs插件
  https://www.npmjs.com/package/sealoader
